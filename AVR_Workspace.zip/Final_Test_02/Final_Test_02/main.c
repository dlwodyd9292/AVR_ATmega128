#define F_CPU 16000000L
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "clcd.h"
#include "i2c_master.h"
#include "UART0.h"
#include "UART1.h"

volatile unsigned int count = 0, sec = 0, min = 0, hour = 12, ampm = 0;
char str[16], clear[16] = "                ";
unsigned char str_temp[16];
int read_temp;
int flag = 0;
uint8_t data;

ISR(INT4_vect) // clock
{	
	flag = 1;
}

ISR(INT5_vect) // DHT11 Humidity & Temperature Sensor
{	
	flag = 2;
}

ISR(INT6_vect) // LED
{	
				PORTB = 0b00001000;
				_delay_ms(1000);
				PORTB = 0b00000100;
				_delay_ms(1000);
				PORTB = 0b00000010;
				_delay_ms(1000);
}


ISR(TIMER0_COMP_vect)//오버플로우 인터럽트의 경우 : TIMER0_OVF_vect
{
TCNT0 = 0; //오버플로우 인터럽트의 경우 TCNT0 = 6;

count++; // 1ms 당 1회씩 증가
if (count > 1000) //1000ms = 1초 증가 
{	
	sec++; count = 0;
	if(sec >= 60)
	{
		min++; sec = 0;
		if (min >= 60)
		{
			hour++; min =0;
			if(hour > 12)
			{
				hour = 0;
				if(ampm == 0) ampm = 1;
				else if(ampm == 1) ampm = 0;
				count =0;
			}
		}
	}
}

}
void ADC_init(unsigned char channel)
{
	ADMUX |= (1 << REFS0); 		// AVCC를 기준 전압으로 선택
	
	ADCSRA |= 0x07;			// 분주비 설정
	ADCSRA |= (1 << ADEN);		// ADC 활성화
	ADCSRA |= (1 << ADFR);		// 프리 러닝 모드

	ADMUX |= ((ADMUX & 0xE0) | channel);	// 채널 선택
	ADCSRA |= (1 << ADSC);		// 변환 시작
}

int read_ADC(void)
{
	while(!(ADCSRA & (1 << ADIF)));	// 변환 종료 대기
	
	return ADC;				// 10비트 값을 반환
}

void INIT_PORT(void)
{
	DDRB = 0xFF;				// PB1,2,3 핀을 출력으로 설정
	PORTB = 0x02;				// LED는 1번 핀만 출력 상태에서 시작
}

void INIT_INT0(void)
{
	EIMSK |= (1 << INT4)|(1 << INT5)|(1 << INT6);			// INT0, INT1, INT2 인터럽트 활성화
	EICRA |= (1 << ISC41) | (1 << ISC40)|(1 << ISC51) | (1 << ISC50)|(1 << ISC61) | (1 << ISC60);	// INT0, INT1, INT2 상승 에지에서 인터럽트 발생
	//INT0, 1, 2, 3 각 2개씩
	//EICRB = INT4, 5, 6, 7 각 2개씩
	sei();							// 전역적으로 인터럽트 허용
}

void timer_init()
{
	// 타이머 인터럽트 레지스터
   /*
	    TIMSK |= (1 << TOIE0); // R/W 선택 TIMER 0 사용
	    TCCR0 |= (1 << CS02); // 분주비 64
	    TCNT0 = 6; // 6에서 시작 255가되어 256이 되면 OVF가 되어 인터럽트 구문을 실행한다.
	    // 오버플로우 인터럽트
    */
   
	    TIMSK |= (1 << OCIE0); // R/W 선택 TIMER 0 사용
	    TCCR0 |= (1 << CS02); // 분주비 64
	    OCR0 = 250; 
            // 비교일치 인터럽트
   
    /*
    1/16000000 = 0.0000000625
    분주비가 64
    0.0000000625 *64 = 0.000004 // TCNT0가 1올라가는 속도.
    ISR이 발생하는 시간 = 0.000004
    TCNT 250 회로 OVF 발생시 걸리는 시간 0.001
    500번이 OVF 인터럽트가 발생하면 1초가 된다.
    */
	
	sei();
}

void BlueTooth_PC_communication()
{
	if((UCSR0A >> RXC0) == 1) // PC를 통해 MCU로 데이터가 들어오는게 완료 되면
	{
		data = UART0_receive(); // PC에서 받은 데이터를 data 변수에 저장
		UART1_transmit(data); // data 변수에 저장된 값을 UART1을 이용해 블루투스 모듈로 전송
	}
	
	if((UCSR1A >> RXC1) == 1) // 블루투스 모듈을 통해 MCU로 데이터가 들어오는게 완료 되면
	{
		data = UART1_receive(); // 블루투스 모듈에서 받은 데이터를 data 변수에 저장
		UART0_transmit(data); // data 변수에 저장된 값을 UART0을 이용해 PC로 전송
	}
}

void Button_control()
{
	
	for(int i = 0; i < 8; i++)
	{
		if(data == '1')
		{
			flag = 1;
		}
		if(data == '2')
		{
			flag = 2;
		}				
	}
}

int main(void)
{	
	//INIT_PORT();
	INIT_INT0();				// INT0 인터럽트 설정
	
	ADC_init(3);
	
	UART0_init(); // MCU - PC
	UART1_init(); // MCU - 블루투스 모듈용	
	
	i2c_lcd_init();
	timer_init();
	
    while (1) 
    {	
		BlueTooth_PC_communication();
		Button_control();
		
		if(flag == 1)
		{				
			sprintf(str," %2d :%2d :%2d %2s", hour, min, sec, (ampm==0)?"AM":"PM");
			i2c_lcd_string(0, 0, str);
		}
 		if(flag == 2)
 		{					 
			read_temp = read_ADC();	
	 		sprintf(str_temp,"ADC : %04d", read_temp);
			i2c_lcd_string(1, 2, str_temp);
 		}

    }
}
