
/*
 * i2c1602clcd.c
 *
 * Created: 2019-07-06 오후 12:42:43
 * Author : user
 */ 

#define F_CPU 16000000

#include <util/delay.h>
#include <avr/io.h>
#include "clcd.h"


int main(void)
{

	i2c_lcd_init();
	
	char str0[16] = "PCF8574 I2C CLCD";
	char str1[16] = "ATMEGA128 HELLO!";
	
	char name[16] = "LEE JAE YONG";
	char career[16] = "EMBEDED PRO";
	

	i2c_lcd_string(0, 0, str0);
	i2c_lcd_string(1, 0, str1);
	
	
	DDRC = 0x0F;
	_delay_ms(1000);

	
	i2c_lcd_command(0x01); _delay_ms(3);
	
	while(1)
	{
		i2c_lcd_string(0, 0, name);
		i2c_lcd_string(1, 0, career);
	}

}
