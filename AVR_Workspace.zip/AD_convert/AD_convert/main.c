/*
 * AD_convert.c
 *
 * Created: 2021-06-17 오후 4:39:46
 * Author : kccistc
 */ 

#define F_CPU 16000000L
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "UART0.h"

FILE OUTPUT = FDEV_SETUP_STREAM(UART0_transmit, NULL, _FDEV_SETUP_WRITE);
FILE INPUT = FDEV_SETUP_STREAM(NULL, UART0_receive, _FDEV_SETUP_READ);

/*
void ADC_init(unsigned char channel)
{
	ADMUX |= (1 << REFS0); 		// AVCC를 기준 전압으로 선택
	
	ADCSRA |= 0x07;			// 분주비 설정
	ADCSRA |= (1 << ADEN);		// ADC 활성화
	ADCSRA |= (1 << ADFR);		// 프리 러닝 모드

	ADMUX = ((ADMUX & 0xE0) | channel);	// 채널 선택
	ADCSRA |= (1 << ADSC);		// 변환 시작
}

int read_ADC(void)
{
	while(!(ADCSRA & (1 << ADIF)));	// 변환 종료 대기
	
	return ADC;				// 10비트 값을 반환
}

int main(void)
{
	int read;
	
	stdout = &OUTPUT;
	stdin = &INPUT;
	
	UART0_init();				// UART 통신 초기화
	ADC_init(0);				// AD 변환기 초기화
	
	while(1)
	{
		read = read_ADC();			// 가변저항 값 읽기

		printf("%d\r\n", read);
		
		_delay_ms(100);			// 1초에 한 번 읽음
	}

	return 0;
}*/

void ADC_init(unsigned char channel)
{
	ADMUX |= (1 << REFS0); 		// AVCC를 기준 전압으로 선택
	
	ADCSRA |= 0x07;			// 분주비 설정
	ADCSRA |= (1 << ADEN);		// ADC 활성화
	ADCSRA |= (1 << ADFR);		// free running 모드

	ADMUX = ((ADMUX & 0xE0) | channel);	// 채널 선택
	ADCSRA |= (1 << ADSC);		// 변환 시작
}

int read_ADC(void)
{
	while(!(ADCSRA & (1 << ADIF)));	// 변환 종료 대기
	
	return ADC;				// 10비트 값을 반환
}

int main(void)
{
	int read;
	
	stdout = &OUTPUT;
	stdin = &INPUT;
	
	UART0_init();				// UART 통신 초기화
	ADC_init(0);				// AD 변환기 초기화
	
	DDRB = 0xFF;				// 포트 B를 출력으로 설정
	
	while(1)
	{
		read = read_ADC();			// 가변저항 값 읽기

		uint8_t pattern = 0;			// LED 제어값
		int LED_count = (read >> 7);	// 켜질 LED의 개수
		// 0 ~ 1023의 값을 (>> 7 = 128)로 나누면 켜질 LED 개수가 나온다  
		
		float reg = (float)(10000/1023)*read;
		
		for(int i = 0; i < LED_count+1; i++){	// LED 제어값 생성
			pattern |= (0x01 << i);
		}
				
		PORTB = pattern;			// LED 켜기
		
		printf("Read : %d,\t Registance : %f, %d LEDs are ON!\r\n", read, reg, LED_count);
		
		_delay_ms(100);
	}

	return 0;
}


